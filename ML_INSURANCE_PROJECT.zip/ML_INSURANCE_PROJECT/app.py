import streamlit as st
import numpy as np
import pandas as pd
import joblib


model = joblib.load("svr_model.pkl")
st.set_page_config(page_title="Insurance Cost Predictor")

st.title("💰 Medical Insurance Cost Predictor")
st.write("Predict insurance charges using Machine Learning")


age = st.slider("Age", 18, 65, 30)
sex = st.selectbox("Sex", ["Male", "Female"])
bmi = st.slider("BMI", 15.0, 50.0, 25.0)
children = st.selectbox("Number of Children", [0, 1, 2, 3, 4, 5])
smoker = st.selectbox("Smoker", ["Yes", "No"])
region = st.selectbox(
    "Region",
    ["northwest", "northeast", "southwest", "southeast"]
)


sex = 1 if sex == "Male" else 0
smoker = 1 if smoker == "Yes" else 0

region_northwest = 1 if region == "northwest" else 0
region_southeast = 1 if region == "southeast" else 0
region_southwest = 1 if region == "southwest" else 0


input_df = pd.DataFrame([[
    age, sex, bmi, children, smoker,
    region_northwest, region_southeast, region_southwest
]], columns=[
    "age", "sex", "bmi", "children", "smoker",
    "region_northwest", "region_southeast", "region_southwest"
])

if st.button("Predict Insurance Cost"):
    log_pred = model.predict(input_df)
    prediction = np.expm1(log_pred)[0]

    st.success(f"Estimated Insurance Cost: ₹ {prediction:,.2f}")
